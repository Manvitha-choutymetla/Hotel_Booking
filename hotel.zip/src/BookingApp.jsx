import React, { useState, useEffect, useReducer } from 'react';
import { Container, Box, CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import { UserContext } from './context/UserContext.js';
import { bookingReducer } from './reducers/BookingReducer.js';
import FilterSection from './components/FilterSection.jsx';
import RoomList from './components/RoomList.jsx';
import BookingsList from './components/BookingsList.jsx';
import { collection, getDocs } from "firebase/firestore";
import { addDoc } from "firebase/firestore";
import { db } from "./firebase.js";
import { auth } from "./firebase.js";
import { deleteDoc, query, where, doc } from "firebase/firestore";

//Material-UI
const theme = createTheme({
  palette: { 
    primary: { main: '#3b82f6' },
    background: { default: '#f5f5f5' }, 
  }, 
  typography: { fontFamily: 'Arial, sans-serif' }, 
});  

//BookingApp component
export default function BookingApp() {
  // State for rooms, bookings, loading status, and filters
  const [rooms, setRooms] = useState([]);
  const [bookings, dispatch] = useReducer(bookingReducer, []);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ date: '', priceRange: 'all' });
  const [userPrefs] = useState({ currency: 'USD', language: 'EN' });

  // Fetch room data on component mount
useEffect(() => {
  const loadData = async () => {
    // Load rooms
    const roomSnapshot = await getDocs(collection(db, "rooms"));
    const roomsData = roomSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setRooms(roomsData);

    // Load bookings for current user
    const q = query(
      collection(db, "bookings"),
      where("userId", "==", auth.currentUser.uid)
    );
    const bookingSnapshot = await getDocs(q);
    const userBookings = bookingSnapshot.docs.map(doc => ({
      id: doc.data().roomId
    }));

    // Sync reducer
    dispatch({ type: "SET_BOOKINGS", payload: userBookings });

    setLoading(false);
  };

  loadData();
}, []);


  // Function to handle booking a room
const handleBookRoom = async (room) => {
  await addDoc(collection(db, "bookings"), {
    userId: auth.currentUser.uid,
    roomId: room.id,
  });

  dispatch({ type: "ADD_BOOKING", payload: { id: room.id } });
};


const handleCancelBooking = async (roomId) => {
  const q = query(
    collection(db, "bookings"),
    where("userId", "==", auth.currentUser.uid),
    where("roomId", "==", roomId)
  );

  const snapshot = await getDocs(q);
  snapshot.forEach(async (item) => {
    await deleteDoc(doc(db, "bookings", item.id));
  });

  dispatch({ type: "REMOVE_BOOKING", payload: roomId });
};



  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <UserContext.Provider value={{ prefs: userPrefs }}>
        <Box sx={{ minHeight: '100vh', backgroundColor: '#f5f5f5', py: 3 }}>
          <Container maxWidth="md">
            {/* App Header */}
            <Box sx={{ mb: 3 }}>
              <h1 style={{ margin: 0, fontSize: '28px', color: '#333' }}>Hotel Booking</h1>
            </Box>

            {/* Filter section for rooms */}
            <FilterSection onFilterChange={setFilters} />
            
            {/* Section title for available rooms */}
            <Box sx={{ mb: 3, mt: 3 }}>
             <h2 style={{ margin: 0, fontSize: '20px', color: '#333' }}>Available Rooms</h2>
            </Box>

            {/* List of available rooms */}
            <RoomList
              rooms={rooms}
             onBook={handleBookRoom}
              bookings={bookings}
              loading={loading}
              filters={filters}
            />
            {/* List of booked rooms */}
            <BookingsList bookings={bookings} onCancel={handleCancelBooking} />
          </Container>
        </Box>
      </UserContext.Provider>
    </ThemeProvider>
  );
}

