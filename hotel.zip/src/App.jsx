import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import BookingApp from "./BookingApp.jsx";
import ProtectedRoute from "./ProtectedRoute.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      
      {/* Protect booking page */}
      <Route
        path="/booking"
        element={
          <ProtectedRoute>
            <BookingApp />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}
