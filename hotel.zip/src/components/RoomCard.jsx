import React from "react";
import { Card, CardContent, Typography, Button, Box } from "@mui/material";

export default function RoomCard({ room, onBook, isAvailable }) {
  return (
    <Card
      sx={{
        borderRadius: "14px",
        border: "1px solid #e9d5ff",
        backgroundColor: "#ffffff",
        boxShadow: "0px 4px 12px rgba(139, 92, 246, 0.12)",
        transition: "0.2s",
        ":hover": { boxShadow: "0px 6px 18px rgba(139, 92, 246, 0.18)" },
      }}
    >
      <CardContent>
        {/* Room Name */}
        <Typography variant="h6" sx={{ fontWeight: 600, color: "#6b21a8", mb: 1 }}>
          {room.name}
        </Typography>

        {/* Room Type */}
        <Typography sx={{ fontSize: "14px", color: "#7e22ce", mb: 1 }}>
          {room.type}
        </Typography>

        {/* Price & Capacity */}
        <Typography sx={{ fontSize: "14px", color: "#555" }}>
          <strong>${room.price}</strong>/night • {room.capacity} guests
        </Typography>

        {/* Button */}
        <Box sx={{ mt: 2 }}>
          <Button
            variant="contained"
            disabled={!isAvailable}
            onClick={() => onBook(room)}
            sx={{
              width: "100%",
              textTransform: "none",
              backgroundColor: isAvailable ? "#a78bfa" : "#ddd",
              color: isAvailable ? "#fff" : "#888",
              ":hover": isAvailable
                ? { backgroundColor: "#8b5cf6" }
                : { backgroundColor: "#ddd" },
            }}
          >
            {isAvailable ? "Book" : "Booked"}
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
}
