import React from 'react';
import { Box, Select, MenuItem, FormControl, InputLabel, Typography } from '@mui/material';

export default function FilterSection({ onFilterChange }) {

  const handlePriceChange = (e) => {
    onFilterChange((prev) => ({ ...prev, priceRange: e.target.value }));
  };

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 2,
        backgroundColor: "#f3e8ff",
        border: "1px solid #d8b4fe",
        padding: "12px",
        marginTop: 2,
        borderRadius: "10px",
      }}
    >
      <Typography sx={{ fontWeight: 600, color: "#6b21a8" }}>
        Filter:
      </Typography>

      <FormControl size="small" sx={{ minWidth: 160 }}>
        <InputLabel>Price Range</InputLabel>
        <Select defaultValue="all" onChange={handlePriceChange}>
          <MenuItem value="all">All</MenuItem>
          <MenuItem value="budget">Budget</MenuItem>
          <MenuItem value="mid">Mid-range</MenuItem>
          <MenuItem value="luxury">Luxury</MenuItem>
        </Select>
      </FormControl>
    </Box>
  );
}

