import React from 'react';
import { Card, CardContent, Typography, Button, Box } from '@mui/material';

export default function BookingsList({ bookings, onCancel }) {
  if (bookings.length === 0) {
    return (
      <Box sx={{ mt: 3, p: 2, backgroundColor: '#e3f2fd', borderRadius: 1 }}>
        <Typography>No bookings yet</Typography>
      </Box>
    );
  }

  return (
    <Card sx={{ mt: 3 }}>
      <CardContent>
        <Typography variant="h6">Your Bookings ({bookings.length})</Typography>
        {bookings.map((booking) => (
          <Box
            key={booking.id}
            sx={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              border: '1px solid #ddd',
              borderRadius: 1,
              p: 2,
              mb: 1
            }}
          >
            <div>
              <Typography sx={{ fontWeight: 'bold' }}>{booking.name}</Typography>
              <Typography variant="caption">${booking.price}/night</Typography>
            </div>

            <Button
              color="error"
              variant="outlined"
              onClick={() => onCancel(booking.id)}
            >
              Remove
            </Button>
          </Box>
        ))}
      </CardContent>
    </Card>
  );
}
