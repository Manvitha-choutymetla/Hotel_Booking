import { db } from "./firebase.js";
import { collection, addDoc } from "firebase/firestore";

const rooms = [
  { name: "Deluxe Suite", type: "Deluxe", price: 200, capacity: 3 },
  { name: "Standard Room", type: "Standard", price: 120, capacity: 2 },
  { name: "Family Suite", type: "Suite", price: 280, capacity: 4 },
  { name: "Executive Room", type: "Deluxe", price: 240, capacity: 3 },
  { name: "Budget Single", type: "Standard", price: 90, capacity: 1 },
  { name: "Luxury Penthouse", type: "Suite", price: 400, capacity: 5 }
];

async function seedRooms() {
  const roomsCollection = collection(db, "rooms");
  for (const room of rooms) {
    await addDoc(roomsCollection, room);
  }
  console.log("✅ Rooms added to Firestore!");
}

seedRooms();
